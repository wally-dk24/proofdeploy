module.exports = { name: "scan-dep" };
